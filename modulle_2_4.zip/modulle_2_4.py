#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on 30 09 2024
@author: igor
"""
numbers = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15]

#n = input("n=")
primes = []
not_primes = []
is_prime = True
for i in numbers[1:]: # 
   # print(i)
    for j in range(2, i):

        if i % j == 0:
            not_primes.append(i)
            is_prime = True
            break
        else: is_prime = False

    if not is_prime :
        primes.append(i)


print(not_primes)
print(primes)

#1:
 #       # остаток от деления
            # если делитель найден, число не простое.
#            break
#    else: print(primes[0:i])
#
#